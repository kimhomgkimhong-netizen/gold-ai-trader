const tvScript = (container, config) => {
  const script = document.createElement("script");
  script.type = "text/javascript";
  script.src = "https://s3.tradingview.com/external-embedding/embed-widget-" + config.widget + ".js";
  script.async = true;
  script.innerHTML = JSON.stringify(config.settings);
  container.appendChild(script);
};

function mountWidget(selector, widget, settings) {
  const container = document.querySelector(selector);
  if (!container) return;
  tvScript(container, { widget, settings });
}

// XAUUSD symbol quote widget. Provider/symbol availability may vary by region.
mountWidget(".price-widget", "single-quote", {
  symbol: "OANDA:XAUUSD",
  colorTheme: "dark",
  isTransparent: true,
  displayMode: "regular",
  width: "100%",
  height: 88,
  locale: "en"
});

// Interactive chart: chart symbol and interval are configurable in the TradingView toolbar.
mountWidget("#tv_chart", "advanced-chart", {
  autosize: true,
  symbol: "OANDA:XAUUSD",
  interval: "5",
  timezone: "Asia/Phnom_Penh",
  theme: "dark",
  style: "1",
  locale: "en",
  enable_publishing: false,
  allow_symbol_change: true,
  hide_top_toolbar: false,
  hide_legend: false,
  save_image: false,
  calendar: false,
  support_host: "https://www.tradingview.com"
});

// Economic calendar.
mountWidget(".economic-widget", "economic-calendar", {
  colorTheme: "dark",
  isTransparent: true,
  width: "100%",
  height: 480,
  locale: "en",
  importanceFilter: "-1,0,1",
  countryFilter: "US"
});

// News feed widget.
mountWidget(".news-widget", "timeline", {
  colorTheme: "dark",
  isTransparent: true,
  displayMode: "regular",
  feedMode: "market",
  market: "crypto",
  width: "100%",
  height: 480,
  locale: "en"
});

const clock = document.querySelector("#clock");
function updateClock() {
  if (!clock) return;
  clock.textContent = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Phnom_Penh",
    dateStyle: "medium",
    timeStyle: "short"
  }).format(new Date());
}
updateClock();
setInterval(updateClock, 30_000);
