# GOLD AI TRADER — ICT / CRT Smart Trader

Cloudflare Pages starter project for an XAUUSD dashboard.

## Included
- TradingView XAUUSD chart widget
- TradingView quote widget (symbol availability can vary)
- TradingView economic calendar widget
- TradingView timeline/news widget
- Responsive dark/gold dashboard
- Signal panel intentionally shows WAIT until a verified candle-data source and strategy engine are connected

## Important data limitation
An embedded TradingView widget is isolated from this app. The website cannot reliably read the chart's live candles or quote directly from the widget to calculate signals. The displayed chart/quote are TradingView reference widgets. For automated ICT/CRT/AMD signals, connect a permitted market-data API or your own data backend, then implement and validate the signal rules. Avoid presenting a fabricated price or signal as live.

## Local development
Requires Node.js 18+.

```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

Vite outputs the static site to `dist/`.

## Deploy to Cloudflare Pages with GitHub
1. Create a new GitHub repository named `gold-ai-trader`.
2. Upload the contents of this folder to the repository root (not the ZIP itself).
3. In Cloudflare Dashboard, open Workers & Pages → your `gold-ai-trader` Pages project.
4. Connect the Git repository and select the repository/production branch.
5. Build settings:
   - Framework preset: Vite
   - Build command: `npm run build`
   - Build output directory: `dist`
6. Save and deploy. Future pushes to the connected branch trigger deployments.

If your current Pages project has a deployment you want to preserve, keep it until the new deployment is verified.

## Trading risk
This is an informational dashboard, not financial advice. No signal or setup has a guaranteed win rate or profit.
